public class Main {
    public static void main(String[] args) {
        /*Notifier sender1 = new Email();
        Notifier sender2 = new Facebook(sender1);
        Notifier sender3 = new Sms(sender2);


        Notifier sender4 = new Twitter(sender1);

        sender3.send("Hi!");*/

        Notifier sender1 = new Facebook(null);

        Notifier sender2 = new Sms(sender1);

        sender2.send("hey");

    }
}