public class Email implements Notifier{

    public Email() {}

    @Override
    public void send(String message) {
        System.out.println("Email:" + message);
    }
}
