public class Sms extends NotifierCustomized{

    public Sms(Notifier notifier) {
        super(notifier);
    }

    public void send(String message) {
        System.out.println("SMS: " + message);
        super.send(message);
    }
}
