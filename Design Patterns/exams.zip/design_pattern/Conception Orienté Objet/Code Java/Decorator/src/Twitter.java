public class Twitter extends NotifierCustomized{

    public Twitter(Notifier notifier) {
        super(notifier);
    }


    public void send(String message) {
        System.out.println("Twitter: " + message);
        super.send(message);
    }
}
