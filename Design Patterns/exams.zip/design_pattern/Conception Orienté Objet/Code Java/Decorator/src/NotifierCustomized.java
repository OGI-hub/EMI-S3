public abstract class NotifierCustomized implements Notifier {

    private Notifier notifier;

    public NotifierCustomized(Notifier notifier) {
        this.notifier = notifier;
    }

    public void send(String message) {
        this.notifier.send(message);
    }

}
