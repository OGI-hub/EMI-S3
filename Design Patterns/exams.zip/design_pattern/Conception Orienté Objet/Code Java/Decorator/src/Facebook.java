public class Facebook extends NotifierCustomized{

    public Facebook(Notifier notifier) {
        super(notifier);
    }

    public void send(String message) {
        System.out.println("Facebook: " + message);
        super.send(message);
    }
}
