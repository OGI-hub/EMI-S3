package Factory.Catalogue;

public class VoitureElectrique extends Voiture{

    public VoitureElectrique(String name, String model, int mat) {
        super(name, model, mat);
    }
}
