package Factory.Catalogue;

public class CamionHybride extends Camion{

    public CamionHybride(String name, String model, int mat) {
        super(name, model, mat);
    }
}
