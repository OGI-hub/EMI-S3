package Factory.Catalogue;

public class CamionElectrique extends Camion{

    public CamionElectrique(String name, String model, int mat) {
        super(name, model, mat);
    }
}
