package Factory.Catalogue;

public class Voiture extends Vehicule{

    public Voiture(String name, String model, int mat) {
        super(name, model, mat);
    }
}
