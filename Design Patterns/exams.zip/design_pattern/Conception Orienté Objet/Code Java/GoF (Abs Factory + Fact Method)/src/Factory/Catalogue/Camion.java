package Factory.Catalogue;

public class Camion extends Vehicule{

    public Camion(String name, String model, int mat) {
        super(name, model, mat);
    }
}
