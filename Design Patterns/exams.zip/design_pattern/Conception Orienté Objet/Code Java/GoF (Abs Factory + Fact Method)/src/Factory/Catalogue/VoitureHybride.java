package Factory.Catalogue;

public class VoitureHybride extends Voiture{

    public VoitureHybride(String name, String model, int mat) {
        super(name, model, mat);
    }
}
