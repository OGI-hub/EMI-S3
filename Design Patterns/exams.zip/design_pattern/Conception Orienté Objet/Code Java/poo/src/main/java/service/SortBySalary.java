package service;

import entite.Employe;

import java.util.Comparator;

public class SortBySalary implements Comparator<Employe> {
    @Override
    public int compare(Employe o1, Employe o2) {
        return Integer.compare(o1.getSalaire(),o2.getSalaire());
        // return o1.getSalaire()>o2.getSalaire() ?1 :-1;
    }
}
