package service;

import DAO.IEmployeDAO;
import entite.Employe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class EmployeService {

    private Comparator<Employe> comparatorEmploye;

    public Comparator<Employe> getComparatorEmploye() {
        return comparatorEmploye;
    }

    public void setComparatorEmploye(Comparator<Employe> comparatorEmploye) {
        this.comparatorEmploye = comparatorEmploye;
    }

    public int sortEmploye(Employe e1,Employe e2){
        return comparatorEmploye.compare(e1,e2);
    }




}
