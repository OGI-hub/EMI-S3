package DAO;

import entite.Employe;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeDAOV1 implements IEmployeDAO{

    BD mybd;

    @Override
    public List<Employe> getAll() {
        return (List<Employe>) mybd.getEmployes().values();
    }

    @Override
    public Integer getById(int id) {

            return (Integer) mybd.getEmployes().get(id);

    }


    @Override
    public Employe create(Employe e) {
        //mybd.getEmployes().put(e.id,e);
        return e;
    }

    @Override
    public Employe Update(Employe e) {
        return null;
    }

    @Override
    public void delete(Employe e) {

    }
}
