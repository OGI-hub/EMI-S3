package entite;

import DAO.IEmployeDAO;

import java.util.List;

public class Employe implements IEmployeDAO  {
    public void setNom(String nom) {
        this.nom = nom;
    }
    private String date_embauche;
    private String fonction;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int mle;
    private int id;
    private String nom;
    private String prenom;

    public String getDate_embauche() {
        return date_embauche;
    }

    public void setDate_embauche(String date_embauche) {
        this.date_embauche = date_embauche;
    }

    public void setSalaire(int salaire) {
        this.salaire = salaire;
    }

    private int salaire;

    public int getSalaire(){
        return this.salaire;
    }
    public String getNom(){
        return this.nom;
    }
    @Override
    public List<Employe> getAll() {
        return null;
    }

    @Override
    public Integer getById(int id) {
        return null;
    }

    @Override
    public Employe create(Employe e) {
        return null;
    }

    @Override
    public Employe Update(Employe e) {
        return null;
    }

    @Override
    public void delete(Employe e) {

    }
    public String toString(){
        return this.nom+" "+this.salaire+" "+this.date_embauche;
    }
    public Employe(String name,int salaire,String date){
        this.nom=name;
        this.salaire=salaire;
        this.date_embauche=date;
    }

}
