package DAO;

import entite.Employe;

import java.util.List;

public interface IEmployeDAO {
    List<Employe> getAll();
    Integer getById(int id);
    Employe create(Employe e);
    Employe Update(Employe e);
    void delete(Employe e);
}
