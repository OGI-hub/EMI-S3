package service;

import entite.Employe;

import java.util.Comparator;

public interface ISort extends Comparator<Employe> {
    SortByName a = new SortByName();
    SortByDate b = new SortByDate();
    SortBySalary c= new SortBySalary();
    public int compare(Employe e1, Employe e2);

}
