package DAO;

import entite.Employe;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BD<e> {
    private Map<Integer, Employe> employes = new HashMap<Integer,Employe>( );
    public Map<Integer, Employe> getEmployes() {
        return employes;
    }





}
