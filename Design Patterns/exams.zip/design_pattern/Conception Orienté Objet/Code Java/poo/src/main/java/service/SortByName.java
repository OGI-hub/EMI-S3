package service;

import entite.Employe;

import java.util.Comparator;

public class SortByName implements Comparator<Employe> {
    public int compare(Employe e1,Employe e2){
        return e1.getNom().compareTo(e2.getNom());
    }
}
