package service;

import entite.Employe;

import java.util.Comparator;

public class SortByDate implements Comparator<Employe> {
    public int compare(Employe o1, Employe o2){
        return o1.getDate_embauche().compareTo(o2.getDate_embauche());
    }
}
