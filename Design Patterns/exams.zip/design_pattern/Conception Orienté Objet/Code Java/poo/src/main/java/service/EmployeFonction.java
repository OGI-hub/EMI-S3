package service;

import entite.Employe;

public abstract class EmployeFonction {
    Employe emp;
    private String function;
    double salaire;
    public String getFonction(Employe emp){
        return function;
    }
    /*public double calculSalaire(Employe emp){
        if(function.equals("manager")){
            salaire=emp.salaire*0.2;
        }
        else if(function.equals("ingenieur IT")){
            salaire=emp.salaire*0.05;
        }
        else if (function.equals("commercial")){
            salaire=emp.salaire*0.02;
        }
        return salaire;
    }*/
}
