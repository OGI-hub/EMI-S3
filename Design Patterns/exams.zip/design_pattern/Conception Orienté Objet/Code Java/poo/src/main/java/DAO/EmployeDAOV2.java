package DAO;

import entite.Employe;

import java.util.List;

public class EmployeDAOV2 implements IEmployeDAO{

    @Override
    public List<Employe> getAll() {
        return null;
    }

    @Override
    public Integer getById(int id) {
        return null;
    }

    @Override
    public Employe create(Employe e) {
        return null;
    }

    @Override
    public Employe Update(Employe e) {
        return null;
    }

    @Override
    public void delete(Employe e) {

    }
}
