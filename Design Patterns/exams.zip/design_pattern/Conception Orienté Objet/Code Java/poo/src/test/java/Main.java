import entite.Employe;
import service.EmployeService;
import service.SortByDate;
import service.SortByName;
import service.SortBySalary;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        ArrayList<Employe> employees = new ArrayList<>();

        Employe e1 = new Employe("meryem",1200,"13/02/2022");
        Employe e2 = new Employe("yassir",1300,"15/06/2022");
        Employe e3 = new Employe("sara",1800,"18/07/2022");

        employees.add(e1);
        employees.add(e2);
        employees.add(e3);

        System.out.println("******* sort by name ********");
        EmployeService service = new EmployeService();
        service.setComparatorEmploye(new SortByName());
        employees.sort((Employe emp1,Employe emp2)-> service.sortEmploye(emp1,emp2));
        employees.forEach(System.out::println);

        System.out.println("******* sort by salary ********");
        service.setComparatorEmploye(new SortBySalary());
        employees.sort((Employe emp1,Employe emp2)-> service.sortEmploye(emp1,emp2));

        employees.forEach(System.out::println);

        System.out.println("******* sort by date ********");
        service.setComparatorEmploye(new SortByDate());
        employees.sort((Employe emp1,Employe emp2)-> service.sortEmploye(emp1,emp2));
        employees.forEach(System.out::println);



    }
}
