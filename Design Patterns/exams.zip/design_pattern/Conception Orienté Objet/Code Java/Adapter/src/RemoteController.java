public class RemoteController implements Controller {


    @Override
    public boolean isLeft() {
        return false;
    }

    @Override
    public boolean isRight() {
        return false;
    }

    @Override
    public boolean isPush() {
        return false;
    }
}
