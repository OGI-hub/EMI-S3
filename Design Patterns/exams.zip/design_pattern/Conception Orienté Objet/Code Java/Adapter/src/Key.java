public enum Key {
    SPACEBAR,
    ARROW_LEFT,
    ARROW_RIGHT

}
