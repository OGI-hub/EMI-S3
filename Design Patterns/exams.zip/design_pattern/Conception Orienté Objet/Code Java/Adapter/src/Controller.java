public interface Controller {
    boolean isLeft();
    boolean isRight();
    boolean isPush();
}
