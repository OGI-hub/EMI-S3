public class VideoGame {

    public void loopGame(){}
}
