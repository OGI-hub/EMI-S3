public class Keyboard {

    public Key key;

    public Key keyPressed(){
        return key;
    }
}
