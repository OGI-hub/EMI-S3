package ma.ac.emi.poo.dao;

import java.util.List;

import ma.ac.emi.poo.entity.Employe;

public interface IEmployeDao {
	List<Employe>getAll();
	Employe getEmployeById(int id);
	

}
