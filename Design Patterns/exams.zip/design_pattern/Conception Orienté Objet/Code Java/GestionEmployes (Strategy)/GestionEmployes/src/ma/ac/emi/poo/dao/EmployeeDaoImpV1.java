package ma.ac.emi.poo.dao;

import java.util.List;

import ma.ac.emi.poo.entity.Employe;

public class EmployeeDaoImpV1 implements IEmployeDao {

	public EmployeeDaoImpV1() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Employe> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employe getEmployeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
