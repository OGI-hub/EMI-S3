package ma.ac.emi.poo.service;

import java.util.Comparator;
import java.util.List;

import ma.ac.emi.poo.dao.IEmployeDao;
import ma.ac.emi.poo.entity.*;

public class EmployeService implements IEmployeService{

	private IEmployeDao dao;
	private Comparator<Employe> employeComparator;
  
  
	public Comparator<Employe> getEmployeComparator() {
		return employeComparator;
	}


	public void setEmployeComparator(Comparator<Employe> employeComparator) {
		this.employeComparator = employeComparator;
	}


	public EmployeService(IEmployeDao d) {
  
		this.setDao(d);
		
		this.setEmployeComparator(employeComparator);
	}

	
	public void setDao(IEmployeDao d) {
		this.dao = d;
	}
	
	public int sortEmployes(Employe e1, Employe e2) {
		return employeComparator.compare(e1, e2);
	}
	
	public List<Employe> showAll(){
		System.out.println("affichage des employees : ");
		return this.dao.getAll();
	}
}
