package ma.ac.emi.poo.service;

import java.util.List;

import ma.ac.emi.poo.dao.IEmployeDao;
import ma.ac.emi.poo.entity.Employe;

public interface IEmployeService {
	
      void setDao(IEmployeDao d) ;
	
	
	
	 List<Employe> showAll();
		
	

}
