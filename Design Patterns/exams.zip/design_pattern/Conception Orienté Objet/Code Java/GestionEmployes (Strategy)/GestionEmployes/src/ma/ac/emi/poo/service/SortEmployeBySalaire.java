package ma.ac.emi.poo.service;

import java.util.Comparator;

import ma.ac.emi.poo.entity.Employe;

public class SortEmployeBySalaire implements Comparator<Employe> {
	
	@Override
	public int compare(Employe e1, Employe e2) {
		return e1.getSalaireBase() > e2.getSalaireBase() ? 1 : -1;
	}
}
