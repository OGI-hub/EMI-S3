package ma.ac.emi.poo.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import ma.ac.emi.poo.dao.EmployeeDaoImpV1;
import ma.ac.emi.poo.dao.IEmployeDao;
import ma.ac.emi.poo.entity.Employe;
import ma.ac.emi.poo.service.EmployeService;
import ma.ac.emi.poo.service.IEmployeService;
import ma.ac.emi.poo.service.SortEmployeByName;


public class Test {

	public static void main(String[] args) {
		
		List<Employe> employes = new ArrayList<>();
		IEmployeDao daov1 = new EmployeeDaoImpV1();
		EmployeService empServ = new EmployeService(daov1);
		
		Employe em1 = new Employe("znas", 123, 5000);
		Employe em2 = new Employe("bdfnas", 1234, 500023);
		Employe em3 = new Employe("Amine", 12345, 50003);
		
		employes.add(em1); employes.add(em2); employes.add(em3);
		
		empServ.setEmployeComparator(new SortEmployeByName());
		
		employes.sort(empServ.getEmployeComparator());
		
		System.out.println(employes);
		
		employes.sort((Employe e1, Employe e2) -> e1.getSalaireBase() < e2.getSalaireBase() ? 1:-1);
		
		System.out.println(employes);
	
		/*
		 * try { Scanner scanner;
		 * 
		 * scanner = new Scanner(new File("config.txt"));
		 * 
		 * // TODO Auto-generated catch block
		 * 
		 * 
		 * 
		 * String daov1 = scanner.nextLine(); String daoV2 = scanner.nextLine(); String
		 * serviceName = scanner.nextLine(); IEmployeDao dao =
		 * (IEmployeDao)Class.forName(daov1).newInstance();
		 * 
		 * IEmployeService service =
		 * (IEmployeService)Class.forName(serviceName).newInstance();
		 * 
		 * 
		 * service.setDao(dao); System.out.println("traitement avec dao v1");
		 * service.showAll();
		 * System.out.println("********************************** \n");
		 * 
		 * dao = (IEmployeDao)Class.forName(daoV2).newInstance();
		 * 
		 * 
		 * 
		 * service.setDao(dao);
		 * 
		 * System.out.println("traitement avec dao v2"); service.showAll(); } catch
		 * (FileNotFoundException e) { e.printStackTrace();
		 * 
		 * } catch (InstantiationException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } catch (IllegalAccessException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } catch
		 * (ClassNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		
		
	}
}
