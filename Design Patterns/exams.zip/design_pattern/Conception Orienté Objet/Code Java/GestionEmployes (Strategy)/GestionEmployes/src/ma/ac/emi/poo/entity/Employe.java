package ma.ac.emi.poo.entity;

import java.time.LocalDate;

public class Employe {
	@Override
	public String toString() {
		return "Employe [name=" + name + ", matricule=" + matricule + ", salaireBase=" + salaireBase + ", age=" + age
				+ "]";
	}

	private String name;
	private int matricule;
	private double salaireBase;
	private int age;
	private LocalDate date;
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalaireBase() {
		return salaireBase;
	}

	public void setSalaireBase(double salaireBase) {
		this.salaireBase = salaireBase;
	}

	public Employe() {
		// TODO Auto-generated constructor stub
	}

	public Employe(String name, int matricule, double salaireBase) {
		super();
		this.setName(name);
		this.setMatricule(matricule);
		this.salaireBase = salaireBase;
	}

	
	public void setName(String newName) {
		if(newName == null || newName.trim().equals(""))
			throw new RuntimeException("Attentin le nom ne doit pas etre nul ! ");
		this.name = newName;
	}
	
	public String getName() {
		return name;
	}

	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
}
