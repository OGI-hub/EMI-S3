public class RosaceAdaptator extends IFormGraphique{

    private float x;
    private float y;

    private static Rosace rosace;

    public RosaceAdaptator(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public static Rosace getRosace() {
        return rosace;
    }

    public static void setRosace(Rosace rosace) {
        RosaceAdaptator.rosace = rosace;
    }

    @Override
    void dessiner() {
        System.out.println("Fuck you" + this.rosace.getAdresse());
    }

    @Override
    public String toString() {
        return "RosaceAdaptator{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}
