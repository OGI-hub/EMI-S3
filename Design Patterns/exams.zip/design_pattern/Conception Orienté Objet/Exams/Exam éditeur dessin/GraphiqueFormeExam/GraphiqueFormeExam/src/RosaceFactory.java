public class RosaceFactory extends FormFactory{


    private static RosaceFactory instance;

    private RosaceFactory(){

    }

    public static RosaceFactory getInstance(){
        if (instance == null) instance = new RosaceFactory();
        return instance;
    }


    @Override
    IFormGraphique creer(float x, float y) {
        return new RosaceAdaptator(x,y);
    }
}
