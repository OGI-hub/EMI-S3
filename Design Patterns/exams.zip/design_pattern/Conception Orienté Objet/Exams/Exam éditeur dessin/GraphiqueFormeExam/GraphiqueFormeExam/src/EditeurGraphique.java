import java.util.ArrayList;
import java.util.List;

public class EditeurGraphique {


    private Dessin dessin;

//    private List<IFormGraphique> dessin = new ArrayList<>();

    private FormFactory formFactory;

    public EditeurGraphique(Dessin dessin) {
        this.dessin = dessin;
    }

    public FormFactory getFormFactory() {
        return formFactory;
    }

    public void setFormFactory(FormFactory formFactory) {
        this.formFactory = formFactory;
    }

    public void createShape(int x , int y){
        IFormGraphique shape = this.formFactory.fabricate(x , y);
        this.dessin.getiFormGraphique().add(shape);
    }

    public void dessine(){
        this.dessin.dessinn();
    }


}
