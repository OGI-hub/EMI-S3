public class Main {
    public static void main(String[] args) {

        Dessin dessin = new Dessin();
        Rosace rosace = new Rosace(1000);

        EditeurGraphique editeurGraphique = new EditeurGraphique(dessin);

        editeurGraphique.setFormFactory(LigneFactory.getInstance());
        editeurGraphique.createShape(5,6);

        editeurGraphique.setFormFactory(RectangleFactory.getInstance());
        editeurGraphique.createShape(5,9);
        editeurGraphique.createShape(5,105);

        editeurGraphique.setFormFactory(RosaceFactory.getInstance());
        RosaceAdaptator.setRosace(rosace);
        editeurGraphique.createShape(45,454);



        editeurGraphique.dessine();

    }
}