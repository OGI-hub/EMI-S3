public class Ligne extends IFormGraphique{


    private float x;
    private float y;


    public Ligne(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "Ligne{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }

    @Override
    void dessiner() {

    }

}
