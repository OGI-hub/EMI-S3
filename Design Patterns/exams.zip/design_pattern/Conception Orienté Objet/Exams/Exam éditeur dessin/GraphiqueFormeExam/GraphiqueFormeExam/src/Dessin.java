import java.util.ArrayList;
import java.util.List;

public class Dessin {

    private List<IFormGraphique> iFormGraphique = new ArrayList<>();

    public Dessin() {
    }

    public List<IFormGraphique> getiFormGraphique() {
        return iFormGraphique;
    }

    public void setiFormGraphique(List<IFormGraphique> iFormGraphique) {
        this.iFormGraphique = iFormGraphique;
    }

    public void dessinn(){
        for (IFormGraphique form: iFormGraphique) {
            System.out.println(form);
        }
    }
}
