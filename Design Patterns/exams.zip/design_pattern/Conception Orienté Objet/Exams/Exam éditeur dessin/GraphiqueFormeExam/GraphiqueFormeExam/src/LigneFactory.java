public class LigneFactory extends FormFactory{


    private static LigneFactory instance;

    public static LigneFactory getInstance(){
        if(instance == null) instance = new LigneFactory();
        return instance;
    }

    @Override
    IFormGraphique creer(float x, float y) {
        return new Ligne(x , y);
    }
}
