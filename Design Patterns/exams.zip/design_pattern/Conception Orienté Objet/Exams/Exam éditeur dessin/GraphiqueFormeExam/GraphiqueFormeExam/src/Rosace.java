public class Rosace {

    private int adresse;

    public Rosace(int adresse) {
        this.adresse = adresse;
    }

    public int getAdresse() {
        return adresse;
    }

    public void setAdresse(int adresse) {
        this.adresse = adresse;
    }

}
