public class RectangleFactory extends FormFactory{

    private static RectangleFactory instance;

    private RectangleFactory() {
    }

    public static RectangleFactory getInstance(){
        if(instance == null) instance = new RectangleFactory();
        return instance;
    }

    @Override
    IFormGraphique creer(float x, float y) {
        return new Rectangle(x , y);
    }
}
