public abstract class FormFactory {


    abstract IFormGraphique creer(float x, float y);

    public IFormGraphique fabricate(float x , float y){
        return creer(x,y);
    }
}
