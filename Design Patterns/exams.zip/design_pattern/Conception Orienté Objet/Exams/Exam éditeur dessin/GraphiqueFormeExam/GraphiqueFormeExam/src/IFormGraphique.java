public abstract class IFormGraphique {



    abstract void dessiner();
}
