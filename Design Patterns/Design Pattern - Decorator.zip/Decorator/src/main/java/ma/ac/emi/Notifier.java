package ma.ac.emi;

public interface Notifier {
    void sendMessage(String message);
}
